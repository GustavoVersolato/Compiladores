/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
//package compilador;

/**
 *
 * @author unifgversolato
 */
public class tradutor  extends atribuicaoBaseListener{
    
    @Override 
    public void enterCmd(atribuicaoParser.CmdContext ctx) { 
        if(ctx.cmdLeia()!= null){
            System.out.println("import java.util.Scanner;");
        }
        System.out.println("public class Code{");
        System.out.println("    public static void main(String[] args){");  
    }
    
    @Override 
    public void exitCmd(atribuicaoParser.CmdContext ctx) { 
        System.out.println("\n  }");
        System.out.println("\n}");   
    }
    
    @Override 
    public void enterCmdLeia(atribuicaoParser.CmdLeiaContext ctx) { 
        System.out.println("      Scanner scanner = new Scanner(System.in);");
        System.out.print("      String " );  
    }
    
    /*@Override 
    public void exitCmdLeia(atribuicaoParser.CmdLeiaContext ctx) { 
        System.out.print(" = scanner.next();");
    }*/
    

    @Override 
    public void enterCmdImprime(atribuicaoParser.CmdImprimeContext ctx) { 
        System.out.print("      System.out.print");
    }
    
    
    @Override
    public void enterTipo(atribuicaoParser.TipoContext ctx) {
        String tipo = ctx.getText();

        switch(tipo){
          case "booleano" -> System.out.print("      Boolean ");
          case "inteiro" -> System.out.print("      int ");
          case "flutuante" -> System.out.print("      double ");
          case "palavra" -> System.out.print("      String ");
        }
  }
    
    @Override 
    public void enterOperadorAtri(atribuicaoParser.OperadorAtriContext ctx) { 
        System.out.print(" = ");
    }
    
    @Override
    public void exitFim(atribuicaoParser.FimContext ctx){
        System.out.print("; ");
    }
    
    @Override 
    public void enterComplementoLeia(atribuicaoParser.ComplementoLeiaContext ctx) { 
         System.out.print(" = scanner.next()");   
    }
    
    @Override
    public void exitPlus(atribuicaoParser.PlusContext ctx){
        System.out.print(" + ");
    }
    
    @Override 
    public void enterComparador(atribuicaoParser.ComparadorContext ctx) { 
        String com = ctx.getText();
        
        switch(com){
            case "==" -> System.out.print(" == ");
            case "<" -> System.out.print(" < ");
            case ">" -> System.out.print(" > ");
            case "<=" -> System.out.print(" <= ");
            case ">=" -> System.out.print(" >= ");
            case "!=" -> System.out.print(" != ");
        }        
    }
    
    @Override 
    public void enterNumero(atribuicaoParser.NumeroContext ctx) { 
        System.out.print(ctx.NUM().getText());
    }
    
    @Override 
    public void enterId(atribuicaoParser.IdContext ctx) { 
        System.out.print("      "+ ctx.ID().getText());
    }
    
    @Override 
    public void enterTexto(atribuicaoParser.TextoContext ctx) { 
        System.out.print(ctx.TEXTO().getText());
    }
    
    @Override 
    public void enterLeftParen(atribuicaoParser.LeftParenContext ctx) { 
        System.out.print("(");
    }
    
    @Override 
    public void enterRightParen(atribuicaoParser.RightParenContext ctx) { 
        System.out.print(")");
    }
    
    /*@Override 
    public void enterExpressao(atribuicaoParser.ExpressaoContext ctx) {

    }*/
    
    /*@Override 
    public void enterTermo(atribuicaoParser.TermoContext ctx) { 
        System.out.print(ctx.fator().getText()+ ctx.termoLinha().getText());
    }*/
    
    /*@Override 
    public void enterExpreLinha(atribuicaoParser.ExpreLinhaContext ctx) {
        System.out.println(" + "+ctx.termo().getText()+ctx.expreLinha().getText());  
    }*/
}
