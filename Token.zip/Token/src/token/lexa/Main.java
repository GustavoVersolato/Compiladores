/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package token.lexa;

import java.util.Scanner;

/**
 *
 * @author unifgversolato
 */
public class Main {
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner sc = new Scanner(System.in);
        System.out.println("Entrada: ");
        String texto = sc.nextLine();
        Lexa lexer = new Lexa(texto);
        Token token = lexer.getNextToken();
        
        while(!"EOF".equals(token.tipo)){
            System.out.println(token);
            token = lexer.getNextToken();
        }
    }
}
