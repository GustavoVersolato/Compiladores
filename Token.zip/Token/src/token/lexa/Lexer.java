package token.lexa;

import java.util.List;
import java.util.ArrayList;

public class Lexer{

  private String texto;
  private int pos;
  private char current_char;
  private List<AFD> afds;

  public Lexer(String texto){
    this.texto = texto;
    this.pos = 0;  
    this.current_char = texto.charAt(pos);
    afds = new ArrayList<>();
    afds.add(new Plus());
    afds.add(new Minus());
  }

  public void error(){
    throw new RuntimeException("invalid character");
  }

  public void advance(int qtde){
    pos += qtde;
    if (pos > (texto.length()-1)){
      current_char = '!';
        System.out.println("aaaa");
    }else{
      current_char = texto.charAt(pos);
    }
  }

  public void skip_whitespace(){
    while (current_char != '!' && current_char == ' '){
      advance(1);
    }
  }

  public boolean isDigit(char c){
    switch(c){
      case '0':
      case '1':
      case '2':
      case '3':
      case '4':
      case '5':
      case '6':
      case '7':
      case '8':
      case '9':
        return true;
    }
    return false;
  }

  public String getInteger(){
    String result="";
    while(current_char != '!' && isDigit(current_char)){
      result += current_char;
      advance(1);
    }
    return result;
  }

  public Token getNextToken(){
    
    while(current_char != '!'){
      if (current_char == ' '){
        skip_whitespace();
        continue;
      }

      /*if (isDigit(current_char)){
          return new Token("INTEGER", getInteger());
      }*/

      /*if (current_char == '+'){
        advance();
        return new Token("PLUS", "+");
      }*/
      
      for (AFD afd : afds){
          Token reconhecido= afd.processa(pos,texto);
          if (reconhecido != null){
              advance(reconhecido.getLength());
              return reconhecido;
          }
      }

      /*if (current_char == '-'){
        advance();
        return new Token("MINUS", "-");
      }

      if (current_char == '*'){
        advance();
        return new Token("MUL", "*");
      }

      if (current_char == '/'){
        advance();
        return new Token("DIV", "/");
      }

      if (current_char == '('){
        advance();
        return new Token("LPAREN", "(");
      }

      if (current_char == ')'){
        advance();
        return new Token("RPAREN", ")");
      }*/

      error();
    }
    return new Token("EOF", "!",1);
  }
}
