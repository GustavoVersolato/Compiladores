/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package token.lexa;

/**
 *
 * @author unifgversolato
 */
public class Token {
    public String tipo;
    public String valor;
    /**
     * @param args the command line arguments
     */
    
    public Token(String tipo, String valor){
        this.tipo = tipo;
        this.valor = valor;
    }
    public String toString(){
        return "< "+ tipo + ", "+ valor +" >";
    }
    
    
}
