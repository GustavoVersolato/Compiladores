/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package token.lexa;

/**
 *
 * @author unifgversolato
 */
public class Lexa {
    String texto;
    int pos;
    char atual;

    public Lexa(String texto) {
        this.texto = texto;
        pos = 0;
        atual = texto.charAt(0);
    }
    
    
    public void avancar(){
        pos++;
        if(pos>texto.length()-1){
            atual = '?';
        }
        else{
            atual = texto.charAt(pos);
        }
    }
    
    public void pular_espaco(){
        while(atual == ' '){
            avancar();
        }
    }
    
    public Token getNextToken(){
        while(atual!='?'){
            if(atual == ' '){
                pular_espaco();
                continue;
            }
            if (atual =='+'){
                avancar();
                return new Token("SOMA","+");
            }
            erro();
        }
        return new Token("EOF","?");
    } 
    
    public void erro(){
        throw new RuntimeException("character errado");
    }
}
