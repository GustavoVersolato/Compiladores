package token.lexa;

public class Integer implements AFD {

  private int marca = 0;

  public boolean isDigit(char c) {
    switch (c) {
      case '0':
      case '1':
      case '2':
      case '3':
      case '4':
      case '5':
      case '6':
      case '7':
      case '8':
      case '9':
        return true;
    }
    return false;
  }

  public String getInteger(char current_char,String texto, int pos) {
    String result = "";
      
    while (current_char != '!' && isDigit(current_char)) {
      result += current_char;
      if (pos > (texto.length()-1)){
            current_char = '!';
      }else{
        current_char = texto.charAt(pos);
       }
      marca++;
    }
    return result;
  }

  @Override
  public Token processa(int pos, String texto) {
    char current_char = texto.charAt(pos);
    if (isDigit(current_char)) {
      return new Token("INTEGER", getInteger(current_char,texto,pos), marca);
    }
    return null;
  }

}
