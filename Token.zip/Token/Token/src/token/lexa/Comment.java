/*package token.lexa;

public class Comment implements AFD {

  @Override
  public Token processa(int pos, String texto) {
    char current_char = texto.charAt(pos);
    String c = '"';
    if (current_char == '"') {
      pos += 1;
      int i = 0;
      while (current_char != '"') {
        current_char = texto.charAt(pos);
        c.append(current_char);
        pos += 1;
        i += 1;
      }
      c.append('"');
      i += 1;
      return new Token("Comment", c, i);
    }
    return null;
  }
}*/