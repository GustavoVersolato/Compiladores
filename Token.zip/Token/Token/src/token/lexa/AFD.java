/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package token.lexa;

/**
 *
 * @author unifgversolato
 */
public interface AFD {
    public Token processa(int pos, String text);
}
